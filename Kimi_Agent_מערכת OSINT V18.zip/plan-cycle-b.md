# מחזור ב' — Frontend UI

## מטרה
לבנות את כל ממשקי המשתמש החדשים: Vault Dashboard, Metrics Tools, Ollama Panel.

## קבצים ליצור

### 1. VaultPage (`src/pages/VaultPage.tsx`)
- טופס הזנת מפתח API חדש (keyName + value)
- רשימת מפתחות שמורים עם maskedPreview בלבד
- כפתור Verify לכל מפתח (health check)
- כפתור מחיקה
- חיווי סטטוס (ירוק/אדום)

### 2. MetricsPage (`src/pages/MetricsPage.tsx`)
- מחשבון מדדים — Dropdown בחירת מדד מתוך 19 מדדים
- שדות input דינמיים לפי המדד שנבחר
- כפתור חישוב + תוצאה + אינטרפרטציה בעברית
- גרף רדאר להשוואת מדדים
- גרף רשת צמתים (vis-network)

### 3. LinkAnalysisPage (`src/pages/LinkAnalysisPage.tsx`)
- הזנת URL
- זיהוי פלטפורמה אוטומטי
- כפתור Auto-Fetch
- שמירת ניתוח

### 4. AnalysisDashboardPage (`src/pages/AnalysisDashboardPage.tsx`)
- טבלת ניתוחים שמורים
- ייבוא/ייצוא JSON/CSV
- סינון וחיפוש

### 5. LabModePage (`src/pages/LabModePage.tsx`)
- הוספת מספר לינקים
- טבלה השוואתית מרכזית

### 6. OllamaPanel (`src/components/OllamaPanel.tsx`)
- פאנל צד collapsible
- בחירת מודל מתוך רשימה
- System Prompt textarea
- Health indicator (ירוק/אדום)
- טמפרטורה slider

### 7. עדכונים קיימים
- AppLayout.tsx — הוספת "Vault" ו-"Metrics" לסרגל צד
- App.tsx — הוספת routes חדשים
- LanguageContext.tsx — תרגומים בעברית
