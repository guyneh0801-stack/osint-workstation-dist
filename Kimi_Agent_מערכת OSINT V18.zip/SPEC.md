# OSINT Intelligence Workstation - SPEC.md

## 1. Architecture Overview

Full-stack OSINT analysis platform with the following architecture:

```
Client (React 19 + Tailwind 4 + shadcn/ui)
  ↕ tRPC (HTTP + WebSocket subscriptions)
Server (Express + tRPC router)
  ↕ Drizzle ORM
Database (PostgreSQL via Neon)
  ↕
External: OpenRouter API, Brevo SMTP, Twilio, Firecrawl
```

### 1.1 Tech Stack

| Layer | Technology | Version |
|-------|-----------|---------|
| Frontend | React | ^19.0.0 |
| Styling | Tailwind CSS | ^4.0.0 |
| UI | shadcn/ui (Radix) | latest |
| Backend | Express | ^4.21.0 |
| API | tRPC | ^11.0.0 |
| ORM | Drizzle ORM | ^0.44.0 |
| DB | PostgreSQL (Neon) | 16+ |
| Auth | Better Auth | ^1.0.0 |
| LLM | OpenRouter | via tRPC |
| Test | Vitest | ^2.1.0 |
| Build | Vite | ^6.0.0 |

### 1.2 Project Structure

```
/mnt/agents/output/osint-workstation/
├── client/
│   ├── index.html
│   ├── public/
│   └── src/
│       ├── App.tsx              # Route definitions
│       ├── main.tsx             # Providers (tRPC, QueryClient, Auth)
│       ├── index.css            # Global styles, CSS variables
│       ├── _core/hooks/         # useAuth
│       ├── components/
│       │   ├── ui/              # shadcn/ui primitives (53)
│       │   ├── collaboration/
│       │   ├── findings/
│       │   └── visualizations/
│       ├── contexts/            # Language, Theme
│       ├── hooks/
│       ├── lib/                 # Utils, i18n, knowledge-base
│       ├── pages/               # 37 page components
│       └── styles/
├── server/
│   ├── _core/
│   │   ├── context.ts           # tRPC context builder
│   │   ├── trpc.ts              # tRPC instance + procedures
│   │   ├── llm.ts               # OpenRouter LLM integration
│   │   └── auth.ts              # Better Auth handler
│   ├── db.ts                    # Database connection
│   ├── routers.ts               # Main tRPC router
│   ├── storage.ts               # File storage helpers
│   ├── otp-service.ts           # Multi-channel OTP
│   ├── routers-*.ts             # Feature routers
│   └── *.test.ts                # Test files
├── shared/
│   ├── types.ts                 # Shared TS types
│   └── const.ts                 # Shared constants
├── drizzle/
│   ├── schema.ts                # All 59 tables
│   ├── relations.ts             # Table relationships
│   └── meta/
├── docs/
├── package.json
├── vite.config.ts
├── vitest.config.ts
├── tsconfig.json
└── .env.example
```

## 2. Database Schema (PostgreSQL)

### 2.1 Core Tables

```sql
-- Users (managed by Better Auth, extended with roles)
users
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid()
  email         text NOT NULL UNIQUE
  name          text
  role          text NOT NULL DEFAULT 'user' CHECK (role IN ('admin', 'user'))
  image         text
  created_at    timestamp DEFAULT now()
  updated_at    timestamp DEFAULT now()

-- Investigations
investigations
  id            serial PRIMARY KEY
  title         text NOT NULL
  description   text
  status        text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'pending', 'closed', 'archived'))
  priority      text NOT NULL DEFAULT 'medium' CHECK (priority IN ('low', 'medium', 'high', 'critical'))
  domains       text[] DEFAULT '{}'
  tags          text[] DEFAULT '{}'
  owner_id      uuid NOT NULL REFERENCES users(id)
  methodology   text DEFAULT '5W1H'
  created_at    timestamp DEFAULT now()
  updated_at    timestamp DEFAULT now()

-- Findings
findings
  id            serial PRIMARY KEY
  investigation_id integer NOT NULL REFERENCES investigations(id) ON DELETE CASCADE
  title         text NOT NULL
  content       text NOT NULL
  confidence    text NOT NULL DEFAULT 'medium' CHECK (confidence IN ('low', 'medium', 'high', 'confirmed'))
  source_type   text NOT NULL DEFAULT 'manual' CHECK (source_type IN ('manual', 'osint_tool', 'ai_analysis', 'rss', 'scraper'))
  source_url    text
  source_name   text
  entities      jsonb DEFAULT '[]'
  pinned        boolean NOT NULL DEFAULT false
  created_by    uuid NOT NULL REFERENCES users(id)
  created_at    timestamp DEFAULT now()
  updated_at    timestamp DEFAULT now()

-- Notes
notes
  id            serial PRIMARY KEY
  investigation_id integer NOT NULL REFERENCES investigations(id) ON DELETE CASCADE
  title         text NOT NULL
  content       text NOT NULL
  created_by    uuid NOT NULL REFERENCES users(id)
  created_at    timestamp DEFAULT now()
  updated_at    timestamp DEFAULT now()

-- Evidence
evidence
  id            serial PRIMARY KEY
  investigation_id integer NOT NULL REFERENCES investigations(id) ON DELETE CASCADE
  title         text NOT NULL
  description   text
  file_path     text
  file_type     text
  file_size     integer
  hash_sha256   text
  chain_custody jsonb DEFAULT '[]'
  captured_by   uuid NOT NULL REFERENCES users(id)
  captured_at   timestamp DEFAULT now()
  created_at    timestamp DEFAULT now()

-- Reports
reports
  id            serial PRIMARY KEY
  investigation_id integer REFERENCES investigations(id) ON DELETE SET NULL
  title         text NOT NULL
  methodology   text NOT NULL DEFAULT '5W1H'
  sections      jsonb NOT NULL DEFAULT '{}'
  red_team_analysis jsonb DEFAULT '{}'
  status        text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'review', 'final'))
  created_by    uuid NOT NULL REFERENCES users(id)
  created_at    timestamp DEFAULT now()
  updated_at    timestamp DEFAULT now()
```

### 2.2 Entity Graph Tables

```sql
-- Entities
entities
  id            serial PRIMARY KEY
  type          text NOT NULL CHECK (type IN ('person', 'organization', 'location', 'domain', 'email', 'phone', 'username', 'ip_address', 'crypto_address', 'vehicle', 'document'))
  name          text NOT NULL
  aliases       text[] DEFAULT '{}'
  attributes    jsonb DEFAULT '{}'
  status        text NOT NULL DEFAULT 'working' CHECK (status IN ('working', 'confirmed', 'refuted'))
  investigation_id integer REFERENCES investigations(id) ON DELETE SET NULL
  created_by    uuid NOT NULL REFERENCES users(id)
  created_at    timestamp DEFAULT now()
  updated_at    timestamp DEFAULT now()

-- Entity Relationships
entity_relationships
  id            serial PRIMARY KEY
  source_entity_id integer NOT NULL REFERENCES entities(id) ON DELETE CASCADE
  target_entity_id integer NOT NULL REFERENCES entities(id) ON DELETE CASCADE
  relationship_type text NOT NULL CHECK (relationship_type IN ('owns', 'works_for', 'located_at', 'associated_with', 'family', 'communicated_with', 'visited', 'registered', 'linked', 'mentioned_in'))
  evidence      text
  confidence    text NOT NULL DEFAULT 'medium' CHECK (confidence IN ('low', 'medium', 'high', 'confirmed'))
  created_by    uuid NOT NULL REFERENCES users(id)
  created_at    timestamp DEFAULT now()

-- Entity Sources
entity_sources
  id            serial PRIMARY KEY
  entity_id     integer NOT NULL REFERENCES entities(id) ON DELETE CASCADE
  source_url    text
  source_name   text NOT NULL
  source_date   timestamp
  notes         text
  created_by    uuid NOT NULL REFERENCES users(id)
  created_at    timestamp DEFAULT now()

-- Entity Investigation Links
entity_investigation_links
  id            serial PRIMARY KEY
  entity_id     integer NOT NULL REFERENCES entities(id) ON DELETE CASCADE
  investigation_id integer NOT NULL REFERENCES investigations(id) ON DELETE CASCADE
  role          text DEFAULT 'subject'
  UNIQUE(entity_id, investigation_id)

-- Entity Reconciliation Log
entity_reconciliation_log
  id            serial PRIMARY KEY
  primary_entity_id integer NOT NULL REFERENCES entities(id)
  merged_entity_id integer NOT NULL REFERENCES entities(id)
  merged_by     uuid NOT NULL REFERENCES users(id)
  merged_at     timestamp DEFAULT now()
  reason        text
```

### 2.3 Collaboration Tables

```sql
-- Investigation Collaborators
investigation_collaborators
  id            serial PRIMARY KEY
  investigation_id integer NOT NULL REFERENCES investigations(id) ON DELETE CASCADE
  user_id       uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE
  role          text NOT NULL DEFAULT 'viewer' CHECK (role IN ('viewer', 'editor', 'admin'))
  added_by      uuid NOT NULL REFERENCES users(id)
  added_at      timestamp DEFAULT now()
  UNIQUE(investigation_id, user_id)

-- Comments
comments
  id            serial PRIMARY KEY
  investigation_id integer NOT NULL REFERENCES investigations(id) ON DELETE CASCADE
  parent_id     integer REFERENCES comments(id) ON DELETE CASCADE
  content       text NOT NULL
  created_by    uuid NOT NULL REFERENCES users(id)
  created_at    timestamp DEFAULT now()
  updated_at    timestamp DEFAULT now()

-- Activity Feed
activity_feed
  id            serial PRIMARY KEY
  investigation_id integer REFERENCES investigations(id) ON DELETE CASCADE
  user_id       uuid NOT NULL REFERENCES users(id)
  action_type   text NOT NULL
  entity_type   text NOT NULL
  entity_id     integer NOT NULL
  metadata      jsonb DEFAULT '{}'
  created_at    timestamp DEFAULT now()
```

### 2.4 Security & Auth Tables

```sql
-- Device Fingerprints
device_fingerprints
  id            serial PRIMARY KEY
  user_id       uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE
  fingerprint   text NOT NULL
  device_name   text
  device_type   text
  last_ip       text
  last_used     timestamp DEFAULT now()
  trusted       boolean NOT NULL DEFAULT false
  created_at    timestamp DEFAULT now()

-- OTP Requests
otp_requests
  id            serial PRIMARY KEY
  user_id       uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE
  channel       text NOT NULL CHECK (channel IN ('email', 'whatsapp', 'sms'))
  code_hash     text NOT NULL
  expires_at    timestamp NOT NULL
  verified_at   timestamp
  attempts      integer NOT NULL DEFAULT 0
  created_at    timestamp DEFAULT now()

-- User Auth Preferences
user_auth_preferences
  id            serial PRIMARY KEY
  user_id       uuid NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE
  preferred_otp_channel text NOT NULL DEFAULT 'email' CHECK (preferred_otp_channel IN ('email', 'whatsapp', 'sms'))
  require_otp   boolean NOT NULL DEFAULT true
  created_at    timestamp DEFAULT now()
  updated_at    timestamp DEFAULT now()

-- Access Audit Log
access_audit_log
  id            serial PRIMARY KEY
  user_id       uuid REFERENCES users(id)
  action        text NOT NULL
  resource_type text NOT NULL
  resource_id   text
  ip_address    text
  user_agent    text
  success       boolean NOT NULL DEFAULT true
  details       jsonb DEFAULT '{}'
  created_at    timestamp DEFAULT now()
```

### 2.5 Tools & Monitoring Tables

```sql
-- Tool Health Scans
tool_health_scans
  id            serial PRIMARY KEY
  tool_id       text NOT NULL
  tool_name     text NOT NULL
  category      text NOT NULL
  url           text NOT NULL
  status        text NOT NULL CHECK (status IN ('online', 'offline', 'degraded', 'unknown'))
  status_code   integer
  response_time integer
  error_message text
  scanned_at    timestamp DEFAULT now()

-- Tool Overrides
tool_overrides
  id            serial PRIMARY KEY
  tool_id       text NOT NULL UNIQUE
  override_url  text
  alternative_url text
  hidden        boolean NOT NULL DEFAULT false
  updated_by    uuid NOT NULL REFERENCES users(id)
  updated_at    timestamp DEFAULT now()

-- Dead Link Reports
dead_link_reports
  id            serial PRIMARY KEY
  tool_id       text NOT NULL
  tool_name     text NOT NULL
  reported_url  text NOT NULL
  reported_by   uuid NOT NULL REFERENCES users(id)
  notes         text
  status        text NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'fixed', 'wontfix'))
  created_at    timestamp DEFAULT now()
  resolved_at   timestamp

-- Monitors
monitors
  id            serial PRIMARY KEY
  name          text NOT NULL
  target_type   text NOT NULL CHECK (target_type IN ('url', 'domain', 'rss', 'social'))
  target_url    text NOT NULL
  frequency     text NOT NULL DEFAULT 'daily' CHECK (frequency IN ('hourly', 'daily', 'weekly'))
  keywords      text[] DEFAULT '{}'
  investigation_id integer REFERENCES investigations(id) ON DELETE SET NULL
  created_by    uuid NOT NULL REFERENCES users(id)
  is_active     boolean NOT NULL DEFAULT true
  created_at    timestamp DEFAULT now()
  updated_at    timestamp DEFAULT now()

-- Monitor Runs
monitor_runs
  id            serial PRIMARY KEY
  monitor_id    integer NOT NULL REFERENCES monitors(id) ON DELETE CASCADE
  status        text NOT NULL CHECK (status IN ('running', 'success', 'failed'))
  result_summary text
  changes_found boolean NOT NULL DEFAULT false
  started_at    timestamp DEFAULT now()
  completed_at  timestamp

-- Snapshots
snapshots
  id            serial PRIMARY KEY
  investigation_id integer REFERENCES investigations(id) ON DELETE SET NULL
  title         text NOT NULL
  url           text NOT NULL
  content       text
  content_hash  text NOT NULL
  screenshot_path text
  captured_by   uuid NOT NULL REFERENCES users(id)
  captured_at   timestamp DEFAULT now()
```

### 2.6 RSS Intelligence Tables

```sql
-- RSS Feeds
rss_feeds
  id            serial PRIMARY KEY
  title         text NOT NULL
  url           text NOT NULL UNIQUE
  description   text
  category      text
  is_active     boolean NOT NULL DEFAULT true
  last_fetched  timestamp
  created_by    uuid NOT NULL REFERENCES users(id)
  created_at    timestamp DEFAULT now()

-- RSS Articles
rss_articles
  id            serial PRIMARY KEY
  feed_id       integer NOT NULL REFERENCES rss_feeds(id) ON DELETE CASCADE
  title         text NOT NULL
  link          text NOT NULL
  summary       text
  published_at  timestamp
  fetched_at    timestamp DEFAULT now()

-- RSS Keyword Alerts
rss_keyword_alerts
  id            serial PRIMARY KEY
  user_id       uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE
  keywords      text[] NOT NULL DEFAULT '{}'
  investigation_id integer REFERENCES investigations(id) ON DELETE SET NULL
  is_active     boolean NOT NULL DEFAULT true
  created_at    timestamp DEFAULT now()
```

### 2.7 AI & Research Tables

```sql
-- User AI Preferences
user_ai_preferences
  id            serial PRIMARY KEY
  user_id       uuid NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE
  assistant_model text NOT NULL DEFAULT 'openrouter/gpt-4o-mini'
  research_model  text NOT NULL DEFAULT 'openrouter/gpt-4o'
  analysis_model  text NOT NULL DEFAULT 'openrouter/gpt-4o-mini'
  temperature     numeric(3,2) NOT NULL DEFAULT 0.7
  max_tokens      integer NOT NULL DEFAULT 4096
  created_at      timestamp DEFAULT now()
  updated_at      timestamp DEFAULT now()

-- Quick Search History
quick_search_history
  id            serial PRIMARY KEY
  user_id       uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE
  query         text NOT NULL
  response      text
  model_used    text
  tokens_used   integer
  created_at    timestamp DEFAULT now()

-- Search Cache
search_cache
  id            serial PRIMARY KEY
  query_hash    text NOT NULL UNIQUE
  query         text NOT NULL
  response      text NOT NULL
  model_used    text
  expires_at    timestamp NOT NULL
  created_at    timestamp DEFAULT now()

-- Finding Analyses
finding_analyses
  id            serial PRIMARY KEY
  finding_id    integer NOT NULL UNIQUE REFERENCES findings(id) ON DELETE CASCADE
  analysis      text NOT NULL
  model_used    text
  tokens_used   integer
  key_insights  text[] DEFAULT '{}'
  risk_assessment text
  created_at    timestamp DEFAULT now()
  updated_at    timestamp DEFAULT now()

-- Pinned Findings
pinned_findings
  id            serial PRIMARY KEY
  user_id       uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE
  finding_id    integer NOT NULL REFERENCES findings(id) ON DELETE CASCADE
  note          text
  created_at    timestamp DEFAULT now()
  UNIQUE(user_id, finding_id)
```

### 2.8 Admin Tables

```sql
-- Bug Reports
bug_reports
  id            serial PRIMARY KEY
  title         text NOT NULL
  description   text NOT NULL
  severity      text NOT NULL DEFAULT 'medium' CHECK (severity IN ('low', 'medium', 'high', 'critical'))
  status        text NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'in_progress', 'resolved', 'closed'))
  reported_by   uuid NOT NULL REFERENCES users(id)
  assigned_to   uuid REFERENCES users(id)
  created_at    timestamp DEFAULT now()
  updated_at    timestamp DEFAULT now()
  resolved_at   timestamp

-- Feature Requests
feature_requests
  id            serial PRIMARY KEY
  title         text NOT NULL
  description   text NOT NULL
  category      text
  status        text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'under_review', 'approved', 'rejected', 'in_progress', 'completed'))
  votes         integer NOT NULL DEFAULT 0
  requested_by  uuid NOT NULL REFERENCES users(id)
  created_at    timestamp DEFAULT now()
  updated_at    timestamp DEFAULT now()

-- User Notifications
user_notifications
  id            serial PRIMARY KEY
  user_id       uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE
  title         text NOT NULL
  message       text NOT NULL
  type          text NOT NULL DEFAULT 'info' CHECK (type IN ('info', 'warning', 'success', 'error'))
  read_at       timestamp
  created_at    timestamp DEFAULT now()
```

## 3. API Specification (tRPC Routers)

### 3.1 Auth Router (`auth.`)
```typescript
auth.me                — query, returns current user or null
auth.listUsers         — query, admin only, list all users
auth.updateRole        — mutation, admin only, { userId, role }
auth.updatePreferences — mutation, { preferredOtpChannel, requireOtp }
auth.getPreferences    — query, returns user auth preferences
```

### 3.2 Investigation Router (`investigation.`)
```typescript
investigation.list          — query, { status?, priority?, search?, page?, limit? }
investigation.getById       — query, { id }
investigation.create        — mutation, { title, description?, status?, priority?, domains?, tags?, methodology? }
investigation.update        — mutation, { id, ...fields }
investigation.delete        — mutation, { id }
investigation.addCollaborator    — mutation, { investigationId, userId, role }
investigation.removeCollaborator — mutation, { investigationId, userId }
investigation.listCollaborators  — query, { investigationId }
investigation.compare            — query, { ids: number[] }
```

### 3.3 Finding Router (`finding.`)
```typescript
finding.listByInvestigation — query, { investigationId, search?, confidence?, pinned? }
finding.getById             — query, { id }
finding.create              — mutation, { investigationId, title, content, confidence?, sourceType?, sourceUrl?, sourceName?, entities? }
finding.update              — mutation, { id, ...fields }
finding.delete              — mutation, { id }
finding.togglePin           — mutation, { id }
finding.analyzeWithAI       — mutation, { findingId }
```

### 3.4 Note Router (`note.`)
```typescript
note.listByInvestigation — query, { investigationId }
note.create              — mutation, { investigationId, title, content }
note.update              — mutation, { id, title?, content? }
note.delete              — mutation, { id }
```

### 3.5 Evidence Router (`evidence.`)
```typescript
evidence.listByInvestigation — query, { investigationId }
evidence.getById             — query, { id }
evidence.create              — mutation, { investigationId, title, description?, file? }
evidence.delete              — mutation, { id }
```

### 3.6 Report Router (`report.`)
```typescript
report.list             — query, { investigationId?, status?, page?, limit? }
report.getById          — query, { id }
report.create           — mutation, { investigationId?, title, methodology? }
report.update           — mutation, { id, title?, methodology?, sections?, redTeamAnalysis?, status? }
report.delete           — mutation, { id }
report.generateRedTeam  — mutation, { reportId }
```

### 3.7 Entity Router (`entity.`)
```typescript
entity.list               — query, { investigationId?, type?, status?, search?, page?, limit? }
entity.getById            — query, { id }
entity.create             — mutation, { type, name, aliases?, attributes?, status?, investigationId? }
entity.update             — mutation, { id, ...fields }
entity.delete             — mutation, { id }
entity.addRelationship    — mutation, { sourceEntityId, targetEntityId, relationshipType, evidence?, confidence? }
entity.removeRelationship — mutation, { relationshipId }
entity.listRelationships  — query, { entityId }
entity.merge              — mutation, { primaryId, duplicateId, reason? }
entity.bulkIngest         — mutation, { investigationId, format, data }
```

### 3.8 Tool Router (`tool.`)
```typescript
tool.list              — query, returns all 218+ tools from knowledge-base
tool.listCategories    — query, returns tool categories
tool.getFavorites      — query, returns user's favorite tool IDs
tool.toggleFavorite    — mutation, { toolId }
tool.getRecentlyUsed   — query, returns recently used tool IDs (localStorage)
tool.reportDeadLink    — mutation, { toolId, toolName, url, notes? }
tool.getOverrides      — query, admin only
tool.setOverride       — mutation, admin only, { toolId, overrideUrl?, alternativeUrl?, hidden? }
tool.runHealthScan     — mutation, { toolId }
```

### 3.9 AI Router (`ai.`)
```typescript
ai.chat               — subscription, { message, model?, temperature? }
ai.quickSearch        — subscription, { query, model? }
ai.getPreferences     — query, returns user's AI preferences
ai.setPreferences     — mutation, { assistantModel?, researchModel?, analysisModel?, temperature?, maxTokens? }
ai.runResearchPipeline — mutation, { topic, depth?, model? }
```

### 3.10 Monitor Router (`monitor.`)
```typescript
monitor.list         — query, { investigationId?, isActive? }
monitor.getById      — query, { id }
monitor.create       — mutation, { name, targetType, targetUrl, frequency?, keywords?, investigationId? }
monitor.update       — mutation, { id, ...fields }
monitor.delete       — mutation, { id }
monitor.runNow       — mutation, { id }
monitor.listRuns     — query, { monitorId }
```

### 3.11 RSS Router (`rss.`)
```typescript
rss.listFeeds      — query
rss.getFeedById    — query, { id }
rss.createFeed     — mutation, { title, url, description?, category? }
rss.deleteFeed     — mutation, { id }
rss.listArticles   — query, { feedId?, search?, page?, limit? }
rss.createAlert    — mutation, { keywords, investigationId? }
rss.deleteAlert    — mutation, { id }
rss.listAlerts     — query
```

### 3.12 Snapshot Router (`snapshot.`)
```typescript
snapshot.list       — query, { investigationId? }
snapshot.getById    — query, { id }
snapshot.create     — mutation, { investigationId?, title, url }
snapshot.delete     — mutation, { id }
```

### 3.13 Audit Router (`audit.`)
```typescript
audit.list          — query, admin only, { userId?, action?, page?, limit? }
audit.log           — mutation, { action, resourceType, resourceId?, details? }
```

### 3.14 Admin Router (`admin.`)
```typescript
admin.getStats          — query, admin only, returns dashboard stats
admin.listDeadLinks    — query, admin only
admin.resolveDeadLink  — mutation, admin only, { id, status }
admin.listBugReports   — query, admin only, { status?, severity? }
admin.updateBugReport  — mutation, admin only, { id, status, assignedTo? }
admin.listFeatureRequests — query, admin only
admin.updateFeatureRequest — mutation, admin only, { id, status }
admin.listHealthScans  — query, admin only
```

## 4. Frontend Specification

### 4.1 Routes (36 pages)
```
/                          → Dashboard
/investigations            → Investigations
/investigations/:id        → InvestigationDetail
/tools                     → ToolsDirectory
/dorking                   → DorkBuilder
/reports                   → Reports
/reports/:id               → ReportDetail
/ai-assistant              → AIAssistant
/entity-graph              → EntityGraph
/link-analysis             → LinkAnalysis
/visint                    → VisintAnalysis
/pipeline                  → Pipeline
/scraper                   → Scraper
/ingestion                 → BulkIngestion
/monitors                  → Monitor
/rss                       → RssMonitor
/snapshots                 → Snapshots
/pinned                    → PinnedFindings
/export                    → Export
/knowledge                 → KnowledgeBase
/methodology               → Methodology
/methodology-trail         → MethodologyTrail
/canvas/:id                → VisualCanvas
/profile-viewer            → ProfileViewer
/audit                     → AuditLog
/compare                   → CompareInvestigations
/coaching-comparison       → CoachingComparison
/settings/security         → AuthSecuritySettings
/settings/ai               → AISettings
/settings/notifications    → NotificationPreferences
/admin/stats               → AdminStatsDashboard
/admin/dead-links          → AdminDeadLinks
/admin/bug-reports         → AdminBugReports
/admin/feature-requests    → AdminFeatureRequests
```

### 4.2 Layout Structure
- **AppShell**: Sidebar (collapsible) + TopBar + Content Area
- **Sidebar**: Navigation links grouped by category (Investigations, Intelligence, AI, Settings, Admin)
- **TopBar**: Search (Cmd+K), Notifications, User menu, Language toggle
- **Content**: Breadcrumb + Page content

### 4.3 Theme
- Dark theme as default (OSINT tactical aesthetic)
- CSS variables for colors:
  ```css
  --background: 220 20% 8%;
  --foreground: 210 20% 95%;
  --card: 220 18% 10%;
  --card-foreground: 210 20% 95%;
  --popover: 220 18% 12%;
  --primary: 190 100% 50%;
  --primary-foreground: 220 20% 5%;
  --secondary: 220 15% 18%;
  --accent: 270 80% 60%;
  --destructive: 0 80% 50%;
  --border: 220 15% 20%;
  --input: 220 15% 18%;
  --ring: 190 100% 50%;
  --success: 150 80% 45%;
  --warning: 45 90% 50%;
  ```

### 4.4 i18n
- English (default) + Hebrew
- RTL support for Hebrew
- Key-value dictionary: `{ en: string, he: string }`
- Language context with localStorage persistence

## 5. External Integrations

### 5.1 OpenRouter (LLM)
- Base URL: `https://openrouter.ai/api/v1`
- Models: `openrouter/gpt-4o`, `openrouter/gpt-4o-mini`, `openrouter/claude-sonnet-4-20250514`
- API key from env `OPENROUTER_API_KEY`

### 5.2 Brevo SMTP (Email OTP)
- Host: `smtp-relay.brevo.com`
- Port: `587`
- Auth from env `SMTP_USER`, `SMTP_PASSWORD`

### 5.3 Twilio (WhatsApp/SMS OTP)
- Account SID + Auth Token from env
- WhatsApp from number: `+14155238886`

### 5.4 Firecrawl (Web Scraping)
- API key from env `FIRECRAWL_API_KEY`

## 6. Implementation Order

### Phase 1: Foundation
1. Project scaffold (Vite + React + Tailwind + shadcn)
2. Database schema + Neon connection + Drizzle
3. Better Auth setup
4. tRPC router structure
5. App shell + layout + navigation
6. Dashboard page

### Phase 2: Core Features
7. OSINT Tools directory (define 218 tools)
8. Investigation CRUD
9. Finding management
10. Notes + Evidence

### Phase 3: Advanced Intelligence
11. Entity knowledge graph
12. AI assistant + quick search
13. Report engine + PDF export
14. Dork builder

### Phase 4: Operations
15. Monitors + RSS
16. Snapshots + scraper
17. Bulk ingestion

### Phase 5: Security & Admin
18. OTP + device management
19. Audit logging
20. Admin dashboards
21. PWA + polish

### Phase 6: Testing
22. Unit tests for routers
23. Component tests
24. Integration tests
