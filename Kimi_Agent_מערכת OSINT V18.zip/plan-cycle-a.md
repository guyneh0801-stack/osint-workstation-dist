# מחזור א' — Backend Core: Vault + Tool Registry + Ollama + Metrics

## סדר ביצוע
1. DB Migrations (6 tables)
2. Vault Service (AES-256 encryption)
3. Ollama Service (proxy + health)
4. Metrics Engine (19 formulas)
5. Tool Registry + Adapters
6. Agent Router
7. tRPC Routers (vault, agent, ollama, metrics)
8. Integration + Tests

## קבצים ליצור/לעדכן

### Database (drizzle/)
- drizzle/migrations/0014_vault_tool_registry.sql

### Services (server/services/)
- server/services/vault.ts — AES-256-GCM encryption/decryption, key storage
- server/services/ollama.ts — Ollama HTTP proxy, health check
- server/services/metrics/ — 19 formula implementations
  - metrics/facebook.ts (AI, EI)
  - metrics/twitter.ts (QRR, ERI, NVS, VI)
  - metrics/instagram.ts (AER, CD, SI, RPS)
  - metrics/tiktok.ts (TVC, CIR)
  - metrics/overton.ts (OWR, PSI)
  - metrics/crossplatform.ts (NPC, BD)
  - metrics/semantic.ts (COV)
  - metrics/index.ts — registry + router
- server/services/toolRegistry.ts — tool adapters + rate limiter + circuit breaker
- server/services/agentRouter.ts — intent analysis + tool selection + chaining

### Routers (server/routers/)
- server/routers/vault.ts — tRPC router (write-only)
- server/routers/ollama.ts — tRPC router
- server/routers/metrics.ts — tRPC router
- server/routers/agent.ts — tRPC router
- server/routers/index.ts — register new routers

### Tests
- Validate 45 existing tests still pass
- Add new tests for vault, ollama, metrics
