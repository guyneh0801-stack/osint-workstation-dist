export interface AppRouter {
  [key: string]: unknown;
}

const noop = (..._args: unknown[]) => ({}) as any;

// ─── Mock tRPC for static SPA (no backend) ──────────────────────────

const mockUtils = {
  invalidate: async () => {},
  refetch: async () => ({}),
  fetch: async () => ({}),
  setData: () => {},
  setInfiniteData: () => {},
  getData: () => undefined,
};

const utilsHandler: ProxyHandler<object> = {
  get() {
    return new Proxy(mockUtils, utilsHandler);
  },
  apply() {
    return Promise.resolve();
  },
};

// Shared state for mutation tracking (module-level so hook calls see updates)
let mutationState = {
  isPending: false,
  isIdle: true,
  isSuccess: false,
  isError: false,
  error: null as Error | null,
  data: undefined as any,
};

function createMutation<TData = unknown>(options?: {
  onSuccess?: (data: TData) => void;
  onError?: (error: Error) => void;
}) {
  const mutate = (input: unknown) => {
    // Simulate brief pending then success with empty data
    mutationState = { isPending: true, isIdle: false, isSuccess: false, isError: false, error: null, data: undefined };
    setTimeout(() => {
      const result = {} as TData;
      mutationState = { isPending: false, isIdle: false, isSuccess: true, isError: false, error: null, data: result };
      options?.onSuccess?.(result);
    }, 800);
  };

  const mutateAsync = async (input: unknown): Promise<TData> => {
    mutate(input);
    return {} as TData;
  };

  return {
    mutate,
    mutateAsync,
    get isPending() { return mutationState.isPending; },
    get isIdle() { return mutationState.isIdle; },
    get isSuccess() { return mutationState.isSuccess; },
    get isError() { return mutationState.isError; },
    get error() { return mutationState.error; },
    get data() { return mutationState.data; },
  };
}

function createQuery() {
  return {
    data: undefined,
    isLoading: false,
    isError: false,
    error: null,
    isSuccess: false,
    refetch: async () => ({}),
  };
}

function createInfiniteQuery() {
  return {
    data: undefined,
    isLoading: false,
    isError: false,
    error: null,
    fetchNextPage: async () => {},
    hasNextPage: false,
  };
}

const deepHandler: ProxyHandler<object> = {
  get(_target: object, prop: string | symbol) {
    if (typeof prop === "symbol" || prop === "then") return noop;
    const key = prop as string;

    if (key === "useQuery") return createQuery;
    if (key === "useMutation") return createMutation;
    if (key === "useInfiniteQuery") return createInfiniteQuery;
    if (key === "useUtils") return () => new Proxy(mockUtils, utilsHandler);
    if (key === "invalidate") return async () => {};

    return new Proxy(noop, deepHandler);
  },
  apply() {
    return new Proxy(noop, deepHandler);
  },
};

export const trpc = new Proxy(
  {
    useQuery: createQuery,
    useMutation: createMutation,
    useInfiniteQuery: createInfiniteQuery,
    useUtils: () => new Proxy(mockUtils, utilsHandler),
  } as any,
  deepHandler
);
