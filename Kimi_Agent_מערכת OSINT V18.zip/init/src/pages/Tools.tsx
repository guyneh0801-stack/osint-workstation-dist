import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Globe,
  Network,
  Users,
  MapPin,
  Bitcoin,
  Archive,
  EyeOff,
  Brain,
  FileSearch,
  MessageCircle,
  Search,
  BookOpen,
} from "lucide-react";

type ToolCategory =
  | "Domain Intelligence"
  | "Network"
  | "Social Media"
  | "Geolocation"
  | "Cryptocurrency"
  | "Archives"
  | "Dark Web"
  | "AI/ML"
  | "Metadata"
  | "Communication"
  | "Search"
  | "Public Records";

interface OsintTool {
  name: string;
  category: ToolCategory;
  description: string;
  url?: string;
}

const categoryIcons: Record<ToolCategory, React.ReactNode> = {
  "Domain Intelligence": <Globe className="h-4 w-4" />,
  Network: <Network className="h-4 w-4" />,
  "Social Media": <Users className="h-4 w-4" />,
  Geolocation: <MapPin className="h-4 w-4" />,
  Cryptocurrency: <Bitcoin className="h-4 w-4" />,
  Archives: <Archive className="h-4 w-4" />,
  "Dark Web": <EyeOff className="h-4 w-4" />,
  "AI/ML": <Brain className="h-4 w-4" />,
  Metadata: <FileSearch className="h-4 w-4" />,
  Communication: <MessageCircle className="h-4 w-4" />,
  Search: <Search className="h-4 w-4" />,
  "Public Records": <BookOpen className="h-4 w-4" />,
};

const tools: OsintTool[] = [
  {
    name: "WHOIS",
    category: "Domain Intelligence",
    description: "Domain registration data lookup",
  },
  {
    name: "Shodan",
    category: "Network",
    description: "Search engine for internet-connected devices",
  },
  {
    name: "Censys",
    category: "Network",
    description: "Internet asset discovery and monitoring",
  },
  {
    name: "VirusTotal",
    category: "Network",
    description: "Analyze suspicious files, domains, IPs",
  },
  {
    name: "Maltego",
    category: "Network",
    description: "Link analysis and data mining for OSINT",
  },
  {
    name: "theHarvester",
    category: "Domain Intelligence",
    description: "E-mail, subdomain, and name harvesting",
  },
  {
    name: "Sublist3r",
    category: "Domain Intelligence",
    description: "Fast subdomains enumeration",
  },
  {
    name: "Amass",
    category: "Domain Intelligence",
    description: "In-depth attack surface mapping and asset discovery",
  },
  {
    name: "Nmap",
    category: "Network",
    description: "Network discovery and security auditing",
  },
  {
    name: "SpiderFoot",
    category: "Domain Intelligence",
    description: "Automated OSINT collection and reconnaissance",
  },
  {
    name: "OSINT Framework",
    category: "Search",
    description: "Web-based framework for OSINT resources",
  },
  {
    name: "Have I Been Pwned",
    category: "Search",
    description: "Check if email has been compromised in a data breach",
  },
  {
    name: "TinEye",
    category: "Search",
    description: "Reverse image search engine",
  },
  {
    name: "Google Dorks",
    category: "Search",
    description: "Advanced Google search queries for information discovery",
  },
  {
    name: "ExifTool",
    category: "Metadata",
    description: "Read, write, and edit file metadata",
  },
  {
    name: "FOCA",
    category: "Metadata",
    description: "Fingerprinting Organizations with Collected Archives",
  },
  {
    name: "Metagoofil",
    category: "Metadata",
    description: "Extract metadata from public documents",
  },
  {
    name: "Wayback Machine",
    category: "Archives",
    description: "Digital archive of the World Wide Web",
  },
  {
    name: "Archive.today",
    category: "Archives",
    description: "Web page archive and snapshot service",
  },
  {
    name: "Tor Search Engines",
    category: "Dark Web",
    description: "Search the dark web via Ahmia, Torch, etc.",
  },
  {
    name: "Blockchain.com",
    category: "Cryptocurrency",
    description: "Bitcoin block explorer and analytics",
  },
  {
    name: "Etherscan",
    category: "Cryptocurrency",
    description: "Ethereum blockchain explorer",
  },
  {
    name: "Wallet Explorer",
    category: "Cryptocurrency",
    description: "Bitcoin and altcoin wallet explorer",
  },
  {
    name: "Chainalysis",
    category: "Cryptocurrency",
    description: "Blockchain data platform for investigations",
  },
  {
    name: "TruffleHog",
    category: "Search",
    description: "Find leaked credentials in repositories",
  },
  {
    name: "GHunt",
    category: "Communication",
    description: "Offensive Google framework for reconnaissance",
  },
  {
    name: "Sherlock",
    category: "Social Media",
    description: "Hunt down social media accounts by username",
  },
  {
    name: "Social Analyzer",
    category: "Social Media",
    description: "Analyze social media profiles for intelligence",
  },
  {
    name: "GeoSpy",
    category: "Geolocation",
    description: "Geolocate images using AI",
  },
  {
    name: "SunCalc",
    category: "Geolocation",
    description: "Sun position and shadow analysis for geolocation",
  },
  {
    name: "Bellingcat OpenStreetMap",
    category: "Geolocation",
    description: "Tools for geolocation verification",
  },
  {
    name: "Ollama",
    category: "AI/ML",
    description: "Local large language model runner for AI analysis",
  },
  {
    name: "Sentencetransformer",
    category: "AI/ML",
    description: "Text embeddings and semantic search",
  },
  {
    name: "Open Corporates",
    category: "Public Records",
    description: "Open database of companies worldwide",
  },
  {
    name: "PACER",
    category: "Public Records",
    description: "US federal court records access",
  },
  {
    name: "IntelX",
    category: "Search",
    description: "Intelligence X search engine and data archive",
  },
];

const categories: ToolCategory[] = [
  "All",
  "Domain Intelligence",
  "Network",
  "Social Media",
  "Geolocation",
  "Cryptocurrency",
  "Archives",
  "Dark Web",
  "AI/ML",
  "Metadata",
  "Communication",
  "Search",
  "Public Records",
] as const as unknown as ToolCategory[];

export function Tools() {
  const [search, setSearch] = useState("");
  const [activeCategory, setActiveCategory] = useState<string>("All");

  const filtered = tools.filter((t) => {
    const matchesSearch =
      t.name.toLowerCase().includes(search.toLowerCase()) ||
      t.description.toLowerCase().includes(search.toLowerCase());
    const matchesCategory =
      activeCategory === "All" || t.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">OSINT Tools</h1>
        <p className="text-muted-foreground">
          Registry of open-source intelligence tools and resources
        </p>
      </div>

      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="relative max-w-sm">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search tools..."
            className="pl-8"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <p className="text-sm text-muted-foreground">
          {filtered.length} tool{filtered.length !== 1 ? "s" : ""} available
        </p>
      </div>

      <div className="flex flex-wrap gap-2">
        {categories.map((cat) => (
          <Button
            key={cat}
            variant={activeCategory === cat ? "default" : "outline"}
            size="sm"
            onClick={() => setActiveCategory(cat)}
            className="gap-1.5"
          >
            {cat !== "All" && categoryIcons[cat as ToolCategory]}
            {cat}
          </Button>
        ))}
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {filtered.map((tool) => (
          <Card key={tool.name} className="p-4 hover:shadow-md transition-shadow">
            <div className="flex items-start gap-3">
              <div className="mt-0.5 text-muted-foreground">
                {categoryIcons[tool.category]}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-2">
                  <h3 className="font-semibold text-sm truncate">{tool.name}</h3>
                  <Badge variant="secondary" className="text-xs shrink-0">
                    {tool.category}
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground mt-1 leading-relaxed">
                  {tool.description}
                </p>
              </div>
            </div>
          </Card>
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-12 text-muted-foreground">
          <Search className="h-10 w-10 mx-auto mb-3 opacity-50" />
          <p>No tools match your search.</p>
        </div>
      )}
    </div>
  );
}
