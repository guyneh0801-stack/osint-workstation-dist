import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import {
  FileText,
  Plus,
  Eye,
  Download,
  Trash2,
  Search,
  FileBarChart,
} from "lucide-react";

interface Report {
  id: string;
  title: string;
  type: "screening" | "investigation" | "intelligence" | "threat";
  status: "draft" | "final" | "archived";
  created: string;
}

const mockReports: Report[] = [];

export function Reports() {
  const [search, setSearch] = useState("");

  const filtered = mockReports.filter((r) =>
    r.title.toLowerCase().includes(search.toLowerCase())
  );

  const statusVariant = (s: Report["status"]) => {
    switch (s) {
      case "draft":
        return "secondary";
      case "final":
        return "default";
      case "archived":
        return "outline";
      default:
        return "secondary";
    }
  };

  const typeLabel = (t: Report["type"]) => {
    switch (t) {
      case "screening":
        return "Screening";
      case "investigation":
        return "Investigation";
      case "intelligence":
        return "Intelligence";
      case "threat":
        return "Threat";
      default:
        return t;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Reports</h1>
          <p className="text-muted-foreground">
            Generate and manage intelligence reports
          </p>
        </div>
        <Button>
          <Plus className="mr-2 h-4 w-4" />
          Generate Report
        </Button>
      </div>

      <Card className="p-4">
        <div className="relative max-w-sm">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search reports..."
            className="pl-8"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </Card>

      <Card>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Title</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Created</TableHead>
              <TableHead className="w-[120px]">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filtered.length === 0 ? (
              <TableRow>
                <TableCell
                  colSpan={5}
                  className="h-48 text-center text-muted-foreground"
                >
                  <div className="flex flex-col items-center justify-center gap-2">
                    <FileBarChart className="h-10 w-10 text-muted-foreground/50" />
                    <p>No reports generated yet.</p>
                    <p className="text-sm">
                      Create a report from an investigation or screening.
                    </p>
                  </div>
                </TableCell>
              </TableRow>
            ) : (
              filtered.map((report) => (
                <TableRow key={report.id}>
                  <TableCell className="font-medium">
                    <div className="flex items-center gap-2">
                      <FileText className="h-4 w-4 text-muted-foreground" />
                      {report.title}
                    </div>
                  </TableCell>
                  <TableCell>{typeLabel(report.type)}</TableCell>
                  <TableCell>
                    <Badge variant={statusVariant(report.status)}>
                      {report.status}
                    </Badge>
                  </TableCell>
                  <TableCell>{report.created}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1">
                      <Button variant="ghost" size="icon" title="View">
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" title="Download">
                        <Download className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" title="Delete">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
}
