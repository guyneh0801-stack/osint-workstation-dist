import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import {
  Search,
  Plus,
  Eye,
  Pencil,
  Trash2,
  FolderOpen,
  AlertTriangle,
  ArrowUp,
  ArrowDown,
  Minus,
} from "lucide-react";

interface Investigation {
  id: string;
  title: string;
  status: "active" | "pending" | "closed";
  priority: "critical" | "high" | "medium" | "low";
  type: string;
  created: string;
  updated: string;
}

const mockInvestigations: Investigation[] = [];

const statusConfig = {
  active: { label: "Active", variant: "default" as const, icon: null },
  pending: { label: "Pending", variant: "secondary" as const, icon: null },
  closed: { label: "Closed", variant: "outline" as const, icon: null },
};

const priorityConfig = {
  critical: {
    label: "Critical",
    color: "text-red-600 bg-red-50 border-red-200",
    icon: <AlertTriangle className="h-3 w-3" />,
  },
  high: {
    label: "High",
    color: "text-orange-600 bg-orange-50 border-orange-200",
    icon: <ArrowUp className="h-3 w-3" />,
  },
  medium: {
    label: "Medium",
    color: "text-yellow-600 bg-yellow-50 border-yellow-200",
    icon: <Minus className="h-3 w-3" />,
  },
  low: {
    label: "Low",
    color: "text-blue-600 bg-blue-50 border-blue-200",
    icon: <ArrowDown className="h-3 w-3" />,
  },
};

export function Investigations() {
  const [search, setSearch] = useState("");

  const filtered = mockInvestigations.filter((inv) =>
    inv.title.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Investigations</h1>
          <p className="text-muted-foreground">
            Manage and track OSINT investigations
          </p>
        </div>
        <Button>
          <Plus className="mr-2 h-4 w-4" />
          New Investigation
        </Button>
      </div>

      <Card className="p-4">
        <div className="relative max-w-sm">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search investigations..."
            className="pl-8"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </Card>

      <Card>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Title</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Priority</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Created</TableHead>
              <TableHead>Updated</TableHead>
              <TableHead className="w-[120px]">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filtered.length === 0 ? (
              <TableRow>
                <TableCell
                  colSpan={7}
                  className="h-48 text-center text-muted-foreground"
                >
                  <div className="flex flex-col items-center justify-center gap-2">
                    <FolderOpen className="h-10 w-10 text-muted-foreground/50" />
                    <p>No investigations yet. Create your first investigation.</p>
                  </div>
                </TableCell>
              </TableRow>
            ) : (
              filtered.map((inv) => (
                <TableRow key={inv.id}>
                  <TableCell className="font-medium">{inv.title}</TableCell>
                  <TableCell>
                    <Badge variant={statusConfig[inv.status].variant}>
                      {statusConfig[inv.status].label}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <span
                      className={`inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-xs font-medium ${priorityConfig[inv.priority].color}`}
                    >
                      {priorityConfig[inv.priority].icon}
                      {priorityConfig[inv.priority].label}
                    </span>
                  </TableCell>
                  <TableCell>{inv.type}</TableCell>
                  <TableCell>{inv.created}</TableCell>
                  <TableCell>{inv.updated}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1">
                      <Button variant="ghost" size="icon" title="View">
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" title="Edit">
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" title="Delete">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
}
