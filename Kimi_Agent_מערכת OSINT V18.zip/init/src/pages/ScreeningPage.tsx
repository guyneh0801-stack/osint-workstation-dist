import { useState, useEffect, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  Zap,
  Search,
  Brain,
  Shield,
  Wifi,
  WifiOff,
  AlertCircle,
  RefreshCw,
  Info,
  Settings,
  Activity,
  Clock,
  Globe,
  FileSearch,
  ChevronDown,
  CheckCircle2,
  XCircle,
  Loader2,
} from "lucide-react";

type OllamaStatus = "checking" | "online" | "offline" | "cors-blocked";

interface OllamaModel {
  name: string;
  size?: number;
  modified_at?: string;
}

interface LogEntry {
  id: string;
  timestamp: string;
  level: "info" | "success" | "warning" | "error";
  message: string;
}

class OllamaClient {
  private baseUrl: string;

  constructor(baseUrl = "http://localhost:11434") {
    this.baseUrl = baseUrl;
  }

  async checkHealth(): Promise<{
    ok: boolean;
    corsBlocked: boolean;
    models: OllamaModel[];
  }> {
    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 5000);
      const response = await fetch(`${this.baseUrl}/api/tags`, {
        signal: controller.signal,
      });
      clearTimeout(timeout);

      if (!response.ok) {
        return { ok: false, corsBlocked: false, models: [] };
      }

      const data = await response.json();
      const models: OllamaModel[] = (data.models || []).map((m: OllamaModel) => ({
        name: m.name,
        size: m.size,
        modified_at: m.modified_at,
      }));

      return { ok: true, corsBlocked: false, models };
    } catch (err) {
      const errorMessage =
        err instanceof Error ? err.message : String(err);

      if (
        errorMessage.includes("CORS") ||
        errorMessage.includes("Failed to fetch") ||
        errorMessage.includes("NetworkError") ||
        errorMessage.includes("Network request failed")
      ) {
        return { ok: false, corsBlocked: true, models: [] };
      }

      if (err instanceof DOMException && err.name === "AbortError") {
        return { ok: false, corsBlocked: false, models: [] };
      }

      return { ok: false, corsBlocked: false, models: [] };
    }
  }
}

const ollamaClient = new OllamaClient();

function useOllama() {
  const [status, setStatus] = useState<OllamaStatus>("checking");
  const [models, setModels] = useState<OllamaModel[]>([]);
  const [selectedModel, setSelectedModel] = useState<string>("");

  const checkConnection = useCallback(async () => {
    setStatus("checking");
    try {
      const result = await ollamaClient.checkHealth();
      if (result.ok) {
        setStatus("online");
        setModels(result.models);
        if (result.models.length > 0 && !selectedModel) {
          setSelectedModel(result.models[0].name);
        }
      } else if (result.corsBlocked) {
        setStatus("cors-blocked");
        setModels([]);
      } else {
        setStatus("offline");
        setModels([]);
      }
    } catch {
      setStatus("offline");
      setModels([]);
    }
  }, [selectedModel]);

  useEffect(() => {
    checkConnection();
  }, [checkConnection]);

  return { status, models, selectedModel, setSelectedModel, checkConnection };
}

function StatusBadge({ status }: { status: OllamaStatus }) {
  switch (status) {
    case "online":
      return (
        <Badge
          variant="outline"
          className="bg-green-50 text-green-700 border-green-200 gap-1"
        >
          <Wifi className="h-3 w-3" />
          Connected
        </Badge>
      );
    case "offline":
      return (
        <Badge
          variant="outline"
          className="bg-red-50 text-red-700 border-red-200 gap-1"
        >
          <WifiOff className="h-3 w-3" />
          Offline
        </Badge>
      );
    case "cors-blocked":
      return (
        <Badge
          variant="outline"
          className="bg-amber-50 text-amber-700 border-amber-200 gap-1"
        >
          <AlertCircle className="h-3 w-3" />
          CORS Blocked
        </Badge>
      );
    case "checking":
      return (
        <Badge variant="outline" className="gap-1">
          <Loader2 className="h-3 w-3 animate-spin" />
          Checking...
        </Badge>
      );
    default:
      return null;
  }
}

export function ScreeningPage() {
  const { status, models, selectedModel, setSelectedModel, checkConnection } =
    useOllama();

  const [target, setTarget] = useState("");
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [isScreening, setIsScreening] = useState(false);

  const [collectors, setCollectors] = useState({
    domain: true,
    whois: true,
    dns: true,
    ssl: true,
    headers: true,
    social: false,
    crypto: false,
    geolocation: false,
  });

  const [depth, setDepth] = useState("standard");
  const [timeout, setTimeout] = useState("30");

  const addLog = useCallback(
    (level: LogEntry["level"], message: string) => {
      const entry: LogEntry = {
        id: `${Date.now()}-${Math.random().toString(36).slice(2)}`,
        timestamp: new Date().toLocaleTimeString(),
        level,
        message,
      };
      setLogs((prev) => [...prev.slice(-99), entry]);
    },
    []
  );

  const handleQuickScreen = useCallback(async () => {
    if (!target.trim()) {
      addLog("warning", "Please enter a target URL or domain");
      return;
    }
    setIsScreening(true);
    addLog("info", `Starting quick screen for: ${target}`);

    setTimeout(() => {
      addLog("success", `DNS records resolved for ${target}`);
    }, 800);
    setTimeout(() => {
      addLog("info", `WHOIS lookup completed`);
    }, 1200);
    setTimeout(() => {
      addLog("success", `SSL certificate valid — expires in 89 days`);
    }, 1600);
    setTimeout(() => {
      addLog("info", `HTTP headers collected (12 headers)`);
      addLog("success", "Quick screen completed");
      setIsScreening(false);
    }, 2000);
  }, [target, addLog]);

  const handleDeepInvestigation = useCallback(() => {
    if (!target.trim()) {
      addLog("warning", "Please enter a target URL or domain");
      return;
    }
    addLog("info", `Initiating deep investigation for: ${target}`);
    addLog(
      "warning",
      "Deep investigation is a simulated action in this version"
    );
  }, [target, addLog]);

  const handleAiAnalysis = useCallback(() => {
    if (status !== "online") {
      addLog("error", "Ollama is not connected. Cannot run AI analysis.");
      return;
    }
    if (!selectedModel) {
      addLog("error", "No model selected. Please select an Ollama model.");
      return;
    }
    if (!target.trim()) {
      addLog("warning", "Please enter a target URL or domain");
      return;
    }
    addLog("info", `Starting AI analysis using ${selectedModel}...`);
    addLog("success", "AI analysis simulation completed");
  }, [status, selectedModel, target, addLog]);

  const logColor = (level: LogEntry["level"]) => {
    switch (level) {
      case "success":
        return "text-green-600";
      case "warning":
        return "text-amber-600";
      case "error":
        return "text-red-600";
      default:
        return "text-muted-foreground";
    }
  };

  const logIcon = (level: LogEntry["level"]) => {
    switch (level) {
      case "success":
        return <CheckCircle2 className="h-3 w-3 text-green-500 shrink-0" />;
      case "warning":
        return <AlertCircle className="h-3 w-3 text-amber-500 shrink-0" />;
      case "error":
        return <XCircle className="h-3 w-3 text-red-500 shrink-0" />;
      default:
        return <Info className="h-3 w-3 text-blue-400 shrink-0" />;
    }
  };

  return (
    <TooltipProvider>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
              <Shield className="h-6 w-6" />
              OSINT Screening
            </h1>
            <p className="text-muted-foreground">
              Target screening with Ollama AI integration
            </p>
          </div>
          <div className="flex items-center gap-3">
            <StatusBadge status={status} />
            <Button
              variant="outline"
              size="sm"
              onClick={checkConnection}
              disabled={status === "checking"}
              className="gap-1.5"
            >
              <RefreshCw
                className={`h-3.5 w-3.5 ${status === "checking" ? "animate-spin" : ""}`}
              />
              Test Connection
            </Button>
          </div>
        </div>

        {status === "cors-blocked" && (
          <Card className="p-4 border-amber-200 bg-amber-50/50">
            <div className="flex items-start gap-3">
              <AlertCircle className="h-5 w-5 text-amber-600 shrink-0 mt-0.5" />
              <div className="flex-1">
                <h3 className="font-semibold text-amber-800 text-sm">
                  Ollama unreachable (CORS)
                </h3>
                <p className="text-sm text-amber-700 mt-1">
                  Your browser blocked the connection to Ollama due to CORS
                  policy. This happens when the page is served over HTTPS and
                  tries to connect to localhost.
                </p>
                <div className="mt-2 flex items-center gap-2">
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button
                        variant="outline"
                        size="sm"
                        className="border-amber-300 text-amber-800 hover:bg-amber-100"
                      >
                        <Info className="h-3.5 w-3.5 mr-1" />
                        How to fix
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent side="bottom" className="max-w-sm">
                      <div className="space-y-2 text-xs">
                        <p className="font-semibold">To resolve CORS issues:</p>
                        <ol className="list-decimal pl-4 space-y-1">
                          <li>
                            Start Ollama with:{
                              " "}
                            <code className="bg-muted px-1 rounded">
                              OLLAMA_ORIGINS=&apos;*&apos; ollama serve
                            </code>
                          </li>
                          <li>
                            If using a browser extension, try Incognito mode.
                          </li>
                          <li>
                            Use a reverse proxy (e.g., nginx) with proper CORS
                            headers.
                          </li>
                          <li>
                            Run this app locally over HTTP instead of HTTPS.
                          </li>
                        </ol>
                      </div>
                    </TooltipContent>
                  </Tooltip>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={checkConnection}
                    className="border-amber-300 text-amber-800 hover:bg-amber-100"
                  >
                    <RefreshCw className="h-3.5 w-3.5 mr-1" />
                    Retry
                  </Button>
                </div>
              </div>
            </div>
          </Card>
        )}

        {status === "offline" && (
          <Card className="p-4 border-red-200 bg-red-50/50">
            <div className="flex items-start gap-3">
              <WifiOff className="h-5 w-5 text-red-600 shrink-0 mt-0.5" />
              <div>
                <h3 className="font-semibold text-red-800 text-sm">
                  Ollama is offline
                </h3>
                <p className="text-sm text-red-700 mt-1">
                  Ollama does not appear to be running on localhost:11434.
                </p>
                <p className="text-xs text-red-600 mt-1">
                  Install from{" "}
                  <a
                    href="https://ollama.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="underline"
                  >
                    ollama.com
                  </a>{" "}
                  and start it with:{
                    " "}
                  <code className="bg-muted px-1 rounded">ollama serve</code>
                </p>
              </div>
            </div>
          </Card>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main panel */}
          <div className="lg:col-span-2 space-y-4">
            {/* Target & Model */}
            <Card className="p-4 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="target" className="flex items-center gap-1.5">
                    <Globe className="h-3.5 w-3.5" />
                    Target URL / Domain
                  </Label>
                  <Input
                    id="target"
                    placeholder="example.com or https://example.com"
                    value={target}
                    onChange={(e) => setTarget(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") handleQuickScreen();
                    }}
                  />
                </div>
                <div className="space-y-2">
                  <Label className="flex items-center gap-1.5">
                    <Brain className="h-3.5 w-3.5" />
                    AI Model
                  </Label>
                  <Select
                    value={selectedModel}
                    onValueChange={setSelectedModel}
                    disabled={status !== "online" || models.length === 0}
                  >
                    <SelectTrigger>
                      <SelectValue
                        placeholder={
                          status === "online"
                            ? models.length === 0
                              ? "No models found"
                              : "Select model..."
                            : status === "cors-blocked"
                              ? "Ollama unreachable (CORS)"
                              : "Ollama offline"
                        }
                      />
                    </SelectTrigger>
                    {models.length > 0 && (
                      <SelectContent>
                        {models.map((m) => (
                          <SelectItem key={m.name} value={m.name}>
                            {m.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    )}
                  </Select>
                </div>
              </div>

              <Separator />

              {/* Action Buttons */}
              <div className="flex flex-wrap gap-3">
                <Button
                  onClick={handleQuickScreen}
                  disabled={isScreening || !target.trim()}
                  className="gap-1.5"
                >
                  {isScreening ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Zap className="h-4 w-4" />
                  )}
                  Quick Screen
                </Button>
                <Button
                  variant="secondary"
                  onClick={handleDeepInvestigation}
                  disabled={!target.trim()}
                  className="gap-1.5"
                >
                  <Search className="h-4 w-4" />
                  Deep Investigation
                </Button>
                <Button
                  variant="outline"
                  onClick={handleAiAnalysis}
                  disabled={status !== "online" || !target.trim()}
                  className="gap-1.5"
                >
                  <Brain className="h-4 w-4" />
                  AI Analysis
                </Button>
              </div>
            </Card>

            {/* Activity Log */}
            <Card className="p-4">
              <div className="flex items-center justify-between mb-3">
                <h2 className="text-sm font-semibold flex items-center gap-1.5">
                  <Activity className="h-4 w-4" />
                  Activity Log
                </h2>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setLogs([])}
                  disabled={logs.length === 0}
                >
                  Clear
                </Button>
              </div>
              <div className="bg-muted rounded-md p-3 h-64 overflow-y-auto space-y-1.5 font-mono text-xs">
                {logs.length === 0 ? (
                  <p className="text-muted-foreground text-center py-8">
                    No activity yet. Run a screening to see logs.
                  </p>
                ) : (
                  logs.map((log) => (
                    <div key={log.id} className="flex items-start gap-2">
                      {logIcon(log.level)}
                      <span className="text-muted-foreground shrink-0">
                        {log.timestamp}
                      </span>
                      <span className={logColor(log.level)}>
                        {log.message}
                      </span>
                    </div>
                  ))
                )}
              </div>
            </Card>
          </div>

          {/* Right sidebar — Configuration */}
          <div className="space-y-4">
            <Card className="p-4">
              <h2 className="text-sm font-semibold flex items-center gap-1.5 mb-4">
                <Settings className="h-4 w-4" />
                Configuration
              </h2>

              <div className="space-y-4">
                {/* Collectors */}
                <div className="space-y-2">
                  <Label className="text-xs uppercase tracking-wider text-muted-foreground">
                    Data Collectors
                  </Label>
                  <div className="space-y-2">
                    {(
                      [
                        ["domain", "Domain Intelligence"],
                        ["whois", "WHOIS Lookup"],
                        ["dns", "DNS Records"],
                        ["ssl", "SSL Certificate"],
                        ["headers", "HTTP Headers"],
                        ["social", "Social Media"],
                        ["crypto", "Cryptocurrency"],
                        ["geolocation", "Geolocation"],
                      ] as const
                    ).map(([key, label]) => (
                      <div
                        key={key}
                        className="flex items-center justify-between"
                      >
                        <Label
                          htmlFor={`collector-${key}`}
                          className="text-sm cursor-pointer"
                        >
                          {label}
                        </Label>
                        <Switch
                          id={`collector-${key}`}
                          checked={collectors[key]}
                          onCheckedChange={(checked) =>
                            setCollectors((prev) => ({
                              ...prev,
                              [key]: checked,
                            }))
                          }
                        />
                      </div>
                    ))}
                  </div>
                </div>

                <Separator />

                {/* Depth */}
                <div className="space-y-2">
                  <Label className="text-xs uppercase tracking-wider text-muted-foreground flex items-center gap-1">
                    <FileSearch className="h-3 w-3" />
                    Investigation Depth
                  </Label>
                  <Select value={depth} onValueChange={setDepth}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="surface">Surface (fast)</SelectItem>
                      <SelectItem value="standard">Standard</SelectItem>
                      <SelectItem value="deep">Deep (thorough)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Timeout */}
                <div className="space-y-2">
                  <Label className="text-xs uppercase tracking-wider text-muted-foreground flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    Timeout (seconds)
                  </Label>
                  <Select value={timeout} onValueChange={setTimeout}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="10">10s</SelectItem>
                      <SelectItem value="30">30s</SelectItem>
                      <SelectItem value="60">60s</SelectItem>
                      <SelectItem value="120">120s</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </Card>

            {/* Ollama Info Card */}
            {status === "online" && models.length > 0 && (
              <Card className="p-4">
                <h2 className="text-sm font-semibold flex items-center gap-1.5 mb-2">
                  <Brain className="h-4 w-4" />
                  Available Models
                </h2>
                <div className="space-y-1.5">
                  {models.slice(0, 5).map((m) => (
                    <div
                      key={m.name}
                      className="flex items-center justify-between text-xs"
                    >
                      <span className="truncate">{m.name}</span>
                      {m.size && (
                        <span className="text-muted-foreground shrink-0 ml-2">
                          {(m.size / 1e9).toFixed(1)} GB
                        </span>
                      )}
                    </div>
                  ))}
                  {models.length > 5 && (
                    <p className="text-xs text-muted-foreground text-center pt-1">
                      +{models.length - 5} more
                    </p>
                  )}
                </div>
              </Card>
            )}
          </div>
        </div>
      </div>
    </TooltipProvider>
  );
}
