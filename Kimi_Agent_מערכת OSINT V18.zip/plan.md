# Mock Data Cleanup Plan

## Objective
Remove all mock/demo/fake data from the OSINT Intelligence Workstation UI.

## Files with Mock Data (prioritized by visibility)

### Tier 1: Dashboard (most visible)
- `mockActivity` array (8 fake activity items)
- `mockRecentInvestigations` array (5 fake investigations)
- Hardcoded chart data (priorityData, findingsTrend, statusData)
- Hardcoded StatCard values ("14", "156", "89", "7")
- **Action**: Replace with trpc queries, show empty states when no data

### Tier 2: AdminStats
- `mockUsers` array (5 fake users)
- `mockSystemLogs` array (6 fake logs)
- Hardcoded `activityData` chart
- Hardcoded tool usage stats with emoji icons
- **Action**: Replace with empty states, remove emoji stat cards

### Tier 3: AIAssistant
- `generateMockResponse` function with setTimeout fake AI
- **Action**: Wire to actual trpc.ollama.chat mutation

### Tier 4: Other pages (quick check)
- EntityGraph, Monitors, RssMonitor, Snapshots, etc.
- **Action**: Check and clean any hardcoded demo data

## Approach
- 4 parallel sub-agents, each handling a tier
- Replace mock arrays with `[]` or trpc queries
- Replace hardcoded values with "-" or real data
- Add empty state UI where needed
- Build + deploy after all changes
