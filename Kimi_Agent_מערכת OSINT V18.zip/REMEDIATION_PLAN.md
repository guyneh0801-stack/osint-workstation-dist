# OSINT Workstation - Remediation Plan

## Goal: Close all gaps to match the original Manus system

## Phase 1: Critical Pages (Parallel - 3 agents)

### Agent A: Dashboard + Tools Enhancement
- **Dashboard.tsx**: Complete overhaul with:
  - Welcome banner with 4-step flow
  - Getting Started checklist (5 items, toggleable)
  - KPI stats (218 tools, investigations, cases, reports)
  - Security badges (Encrypted, Zero Trust, OPSEC, Audit Trail)
  - Quick Actions cards (7 actions)
  - Intelligence Domain Coverage chart
  - Findings Confidence Distribution
- **ToolsDirectory.tsx**: Add per-tool action buttons (Favorite star, Check health, Report dead link), dark web warning badges, recently used tracking

### Agent B: Analysis Pages (6 pages)
- **ImageAnalysis.tsx**: Full VISINT tool directory + mock upload analysis with EXIF data
- **Methodology.tsx**: Complete with 2 tabs (Methodologies + Frameworks), 8 expandable methodologies
- **AuditLog.tsx**: Full audit table with 15 mock events, filters by date/action/status
- **DorkBuilder.tsx**: Enhanced with operator chips, query preview, history, AI Expand
- **LinkAnalysis.tsx**: Network visualization mock with link analysis tools
- **KnowledgeBase.tsx**: Knowledge base browser with categories and search

### Agent C: Automation + Settings Pages (10 pages)
- **CollectionPipeline.tsx**: Visual pipeline with 6 stages, progress bars, entity extraction
- **PinnedFindings.tsx**: Bookmarked findings with investigation badges, confidence levels
- **ExportCenter.tsx**: Export options (PDF, CSV, JSON), format selection, preview
- **WebScraper.tsx**: URL input, scraping options, mock results table
- **CoachingComparison.tsx**: Side-by-side AI coaching comparison interface
- **SettingsAI.tsx**: Model configuration with dropdowns, API key inputs, save functionality
- **SettingsSecurity.tsx**: MFA toggles, trusted devices table, session management
- **SettingsNotifications.tsx**: Notification toggles, RSS alert keywords
- **AdminDeadLinks.tsx**: Dead link management table with status/actions
- **AdminBugReports.tsx**: Bug report triage with severity/priority/status

## Phase 2: Minor Pages + Polish (2 agents)

### Agent D: Remaining Pages (8 pages)
- **ProfileViewer.tsx**: Secure iframe profile viewer interface
- **BulkIngestion.tsx**: CSV/JSON/URL/Text upload with preview
- **MethodologyTrail.tsx**: Audit trail of methodology usage
- **AdminStats.tsx**: Enhanced admin dashboard with charts
- **AdminFeatureRequests.tsx**: Feature request voting/management
- **UserGuide.tsx**: User guide with searchable sections
- **Shortcuts.tsx**: Keyboard shortcuts reference
- **CompareInvestigations.tsx**: Side-by-side investigation comparison

### Agent E: RTL + i18n Polish
- Fix LanguageContext to properly switch RTL/LTR
- Add Hebrew translations for all UI strings
- Ensure all pages work in both directions
- Add proper text-align and direction handling

## Phase 3: Build & Deploy
- Merge all changes
- Fix any build errors
- Deploy final version

## Key Technical Notes
- Use HashRouter (already set up)
- Use named exports for all pages
- Use shadcn/ui components only
- Use useState for all interactive state
- Use localStorage for persistence (favorites, recently used, settings)
- Dark theme: bg-[#0c1018], primary cyan, border-border/40
